import { 
  Client, 
  Events, 
  GatewayIntentBits, 
  Collection, 
  REST, 
  Routes, 
  SlashCommandBuilder, 
  PermissionFlagsBits 
} from 'discord.js';

// Configuration du client avec tous les intents nécessaires
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildModeration
  ]
});

// Initialisation des collections
client.commands = new Collection();
client.warnings = new Collection();
client.levels = new Map();

// Configuration
const XP_PER_MESSAGE = 15;
const LEVEL_MULTIPLIER = 100;

// Définition des commandes slash
const commands = [
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Répond avec la latence du bot'),

  new SlashCommandBuilder()
    .setName('info')
    .setDescription('Affiche les informations du serveur'),

  new SlashCommandBuilder()
    .setName('aide')
    .setDescription('Affiche la liste des commandes disponibles'),

  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulse un membre')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à expulser')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison de l\'expulsion'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bannit un membre')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à bannir')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison du bannissement'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Met un membre en timeout')
    .addUserOption(option => 
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à mettre en timeout')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('durée')
        .setDescription('Durée en minutes')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison du timeout'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  new SlashCommandBuilder()
    .setName('niveau')
    .setDescription('Affiche votre niveau ou celui d\'un utilisateur')
    .addUserOption(option =>
      option.setName('utilisateur')
        .setDescription('L\'utilisateur dont vous voulez voir le niveau')),

  new SlashCommandBuilder()
    .setName('classement')
    .setDescription('Affiche le classement des membres du serveur'),

  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Supprime un nombre spécifié de messages')
    .addIntegerOption(option =>
      option.setName('nombre')
        .setDescription('Nombre de messages à supprimer')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Avertir un membre')
    .addUserOption(option =>
      option.setName('utilisateur')
        .setDescription('L\'utilisateur à avertir')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('raison')
        .setDescription('La raison de l\'avertissement')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
];

// Événement quand le bot est prêt
client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Bot prêt ! Connecté en tant que ${readyClient.user.tag}`);

  try {
    // Enregistrer les commandes slash
    const rest = new REST().setToken(process.env.DISCORD_TOKEN);
    console.log('Début de l\'enregistrement des commandes slash...');

    await rest.put(
      Routes.applicationCommands(readyClient.user.id),
      { body: commands },
    );

    console.log('Commandes slash enregistrées avec succès !');
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement des commandes:', error);
  }
});

// Gérer les interactions de commandes
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;
  console.log(`Commande reçue: ${commandName} de ${interaction.user.tag}`);

  try {
    switch (commandName) {
      case 'ping':
        const sent = await interaction.reply({ content: 'Calcul de la latence...', fetchReply: true });
        await interaction.editReply(`🏓 Pong! Latence: ${sent.createdTimestamp - interaction.createdTimestamp}ms | Latence API: ${Math.round(client.ws.ping)}ms`);
        break;

      case 'info':
        const guild = interaction.guild;
        await interaction.reply({
          embeds: [{
            title: `ℹ️ Information sur ${guild.name}`,
            fields: [
              { name: '👥 Membres', value: `${guild.memberCount}`, inline: true },
              { name: '📅 Créé le', value: guild.createdAt.toLocaleDateString(), inline: true },
              { name: '👑 Propriétaire', value: `<@${guild.ownerId}>`, inline: true },
              { name: '🎭 Rôles', value: `${guild.roles.cache.size}`, inline: true },
              { name: '💬 Salons', value: `${guild.channels.cache.size}`, inline: true },
              { name: '🎨 Emojis', value: `${guild.emojis.cache.size}`, inline: true }
            ],
            thumbnail: { url: guild.iconURL() || null },
            color: 0x3498db
          }]
        });
        break;

      case 'aide':
        await interaction.reply({
          embeds: [{
            title: '📚 Liste des commandes',
            description: commands.map(cmd => `**/${cmd.name}** - ${cmd.description}`).join('\n'),
            color: 0x2ecc71
          }]
        });
        break;

      case 'kick':
        const kickUser = interaction.options.getUser('utilisateur');
        const kickReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const kickMember = await interaction.guild.members.fetch(kickUser.id);

        console.log(`Tentative d'expulsion de ${kickUser.tag} par ${interaction.user.tag}`);

        if (!kickMember.kickable) {
          console.log(`Impossible d'expulser ${kickUser.tag} - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas expulser cet utilisateur.', ephemeral: true });
        }

        try {
          await kickMember.kick(kickReason);
          console.log(`${kickUser.tag} a été expulsé par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '👢 Membre expulsé',
              description: `**${kickUser.tag}** a été expulsé par ${interaction.user}.\nRaison: ${kickReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors de l'expulsion de ${kickUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors de l\'expulsion.', 
            ephemeral: true 
          });
        }
        break;

      case 'ban':
        const banUser = interaction.options.getUser('utilisateur');
        const banReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const banMember = await interaction.guild.members.fetch(banUser.id);

        console.log(`Tentative de bannissement de ${banUser.tag} par ${interaction.user.tag}`);

        if (!banMember.bannable) {
          console.log(`Impossible de bannir ${banUser.tag} - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas bannir cet utilisateur.', ephemeral: true });
        }

        try {
          await banMember.ban({ reason: banReason });
          console.log(`${banUser.tag} a été banni par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '🔨 Membre banni',
              description: `**${banUser.tag}** a été banni par ${interaction.user}.\nRaison: ${banReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors du bannissement de ${banUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors du bannissement.', 
            ephemeral: true 
          });
        }
        break;

      case 'timeout':
        const timeoutUser = interaction.options.getUser('utilisateur');
        const timeoutDuration = interaction.options.getInteger('durée');
        const timeoutReason = interaction.options.getString('raison') || 'Aucune raison fournie';
        const timeoutMember = await interaction.guild.members.fetch(timeoutUser.id);

        console.log(`Tentative de timeout de ${timeoutUser.tag} par ${interaction.user.tag}`);

        if (!timeoutMember.moderatable) {
          console.log(`Impossible de mettre ${timeoutUser.tag} en timeout - Permissions insuffisantes`);
          return interaction.reply({ content: '❌ Je ne peux pas mettre cet utilisateur en timeout.', ephemeral: true });
        }

        try {
          await timeoutMember.timeout(timeoutDuration * 60 * 1000, timeoutReason);
          console.log(`${timeoutUser.tag} a été mis en timeout par ${interaction.user.tag}`);
          await interaction.reply({
            embeds: [{
              title: '⏰ Membre mis en timeout',
              description: `**${timeoutUser.tag}** a été mis en timeout pour ${timeoutDuration} minutes par ${interaction.user}.\nRaison: ${timeoutReason}`,
              color: 0xe74c3c
            }]
          });
        } catch (error) {
          console.error(`Erreur lors du timeout de ${timeoutUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors du timeout.', 
            ephemeral: true 
          });
        }
        break;

      case 'niveau':
        const targetUser = interaction.options.getUser('utilisateur') || interaction.user;
        const userXP = client.levels.get(targetUser.id) || { xp: 0, level: 0 };
        const nextLevelXP = (userXP.level + 1) * LEVEL_MULTIPLIER;

        await interaction.reply({
          embeds: [{
            title: `📊 Niveau de ${targetUser.username}`,
            fields: [
              { name: 'Niveau', value: `${userXP.level}`, inline: true },
              { name: 'XP', value: `${userXP.xp}/${nextLevelXP}`, inline: true },
              { name: 'Progression', value: `${Math.round((userXP.xp / nextLevelXP) * 100)}%`, inline: true }
            ],
            thumbnail: { url: targetUser.displayAvatarURL() },
            color: 0x9b59b6
          }]
        });
        break;

      case 'classement':
        const sortedLevels = [...client.levels.entries()]
          .sort(([, a], [, b]) => b.xp - a.xp)
          .slice(0, 10);

        const leaderboard = await Promise.all(
          sortedLevels.map(async ([userId, data], index) => {
            const user = await client.users.fetch(userId);
            return `${index + 1}. ${user.username} - Niveau ${data.level} (${data.xp} XP)`;
          })
        );

        await interaction.reply({
          embeds: [{
            title: '🏆 Classement du serveur',
            description: leaderboard.join('\n') || 'Aucun membre classé',
            color: 0xf1c40f
          }]
        });
        break;

      case 'clear':
        const amount = interaction.options.getInteger('nombre');
        const channel = interaction.channel;

        try {
          const messages = await channel.bulkDelete(amount);
          await interaction.reply({
            content: `✅ ${messages.size} messages ont été supprimés.`,
            ephemeral: true
          });
        } catch (error) {
          await interaction.reply({
            content: '❌ Impossible de supprimer les messages. Ils sont peut-être trop anciens (>14 jours).',
            ephemeral: true
          });
        }
        break;

      case 'warn':
        const warnUser = interaction.options.getUser('utilisateur');
        const warnReason = interaction.options.getString('raison');
        const warnMember = await interaction.guild.members.fetch(warnUser.id);

        console.log(`Tentative d'avertissement de ${warnUser.tag} par ${interaction.user.tag}`);

        if (warnMember.roles.highest.position >= interaction.member.roles.highest.position) {
          console.log(`Impossible d'avertir ${warnUser.tag} - Position de rôle supérieure`);
          return interaction.reply({
            content: '❌ Vous ne pouvez pas avertir cet utilisateur.',
            ephemeral: true
          });
        }

        try {
          // Créer les collections si elles n'existent pas
          if (!client.warnings.has(interaction.guildId)) {
            client.warnings.set(interaction.guildId, new Collection());
          }
          const guildWarnings = client.warnings.get(interaction.guildId);
          if (!guildWarnings.has(warnUser.id)) {
            guildWarnings.set(warnUser.id, []);
          }

          const userWarnings = guildWarnings.get(warnUser.id);
          userWarnings.push({
            reason: warnReason,
            moderator: interaction.user.id,
            timestamp: Date.now()
          });

          console.log(`Avertissement ajouté pour ${warnUser.tag}`);

          await interaction.reply({
            embeds: [{
              title: '⚠️ Avertissement',
              description: `**${warnUser.tag}** a été averti par ${interaction.user}.\nRaison: ${warnReason}`,
              fields: [
                { name: 'Nombre d\'avertissements', value: `${userWarnings.length}`, inline: true }
              ],
              color: 0xff9900
            }]
          });

          // Envoyer un DM à l'utilisateur averti
          try {
            await warnUser.send({
              embeds: [{
                title: `⚠️ Vous avez reçu un avertissement sur ${interaction.guild.name}`,
                description: `Raison: ${warnReason}\nModérateur: ${interaction.user.tag}`,
                color: 0xff9900
              }]
            });
          } catch (dmError) {
            console.log(`Impossible d'envoyer un DM à ${warnUser.tag}: ${dmError.message}`);
          }
        } catch (error) {
          console.error(`Erreur lors de l'avertissement de ${warnUser.tag}:`, error);
          await interaction.reply({ 
            content: '❌ Une erreur est survenue lors de l\'avertissement.', 
            ephemeral: true 
          });
        }
        break;
    }
  } catch (error) {
    console.error(`Erreur lors de l'exécution de la commande ${commandName}:`, error);
    const errorMessage = 'Une erreur est survenue lors de l\'exécution de la commande.';
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: errorMessage, ephemeral: true });
    } else {
      await interaction.reply({ content: errorMessage, ephemeral: true });
    }
  }
});

// Système de niveaux - Gérer les messages
client.on(Events.MessageCreate, async message => {
  // Ignorer les messages des bots et les messages privés
  if (message.author.bot || !message.guild) return;

  // Répondre quand le bot est mentionné
  if (message.mentions.has(client.user)) {
    await message.reply('👋 Hey! Utilisez `/aide` pour voir la liste des commandes disponibles.');
    return;
  }

  // Système de niveaux
  try {
    const userId = message.author.id;
    const userData = client.levels.get(userId) || { xp: 0, level: 0 };

    // Ajouter de l'XP
    userData.xp += XP_PER_MESSAGE;

    // Vérifier le niveau
    const newLevel = Math.floor(userData.xp / LEVEL_MULTIPLIER);
    if (newLevel > userData.level) {
      userData.level = newLevel;
      const levelUpChannel = message.guild.channels.cache.find(channel => 
        channel.name === 'niveau-up' || channel.name === 'levels'
      );

      if (levelUpChannel) {
        try {
          await levelUpChannel.send({
            embeds: [{
              title: '🎉 Niveau supérieur !',
              description: `Félicitations ${message.author} ! Tu as atteint le niveau ${newLevel} !`,
              color: 0x2ecc71
            }]
          });
        } catch (error) {
          console.error('Erreur lors de l\'envoi du message de niveau:', error);
        }
      }
    }

    client.levels.set(userId, userData);
  } catch (error) {
    console.error('Erreur dans le système de niveaux:', error);
  }
});

// Gérer les erreurs globales
client.on(Events.Error, error => {
  console.error('Erreur Discord.js:', error);
});

process.on('unhandledRejection', error => {
  console.error('Promesse non gérée:', error);
});

// Connexion du bot
console.log('Tentative de connexion du bot...');
client.login(process.env.DISCORD_TOKEN)
  .then(() => console.log('Bot connecté avec succès !'))
  .catch(error => {
    console.error('Erreur de connexion:', error);
    process.exit(1);
  });