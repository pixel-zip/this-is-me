import type { Express } from "express";
import { createServer } from "http";
import session from "express-session";
import MemoryStore from "memorystore";
import { WebSocket, WebSocketServer } from "ws";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);
  const MemoryStoreSession = MemoryStore(session);

  // Configuration de la session
  app.use(
    session({
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // Nettoie les sessions expirées chaque 24h
      }),
      secret: process.env.SESSION_SECRET || 'votre_secret',
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false } // À mettre à true en production avec HTTPS
    })
  );

  // Route pour démarrer l'authentification Discord
  app.get('/api/auth/discord', (req, res) => {
    // À implémenter: Redirection vers l'auth Discord
    res.json({ message: "Auth Discord à implémenter" });
  });

  // Route pour récupérer la configuration du bot
  app.get("/api/config", async (req, res) => {
    const config = await storage.getBotConfig();
    res.json(config || { status: "unconfigured" });
  });

  // Route pour mettre à jour la configuration du bot
  app.post("/api/config", async (req, res) => {
    const config = insertBotConfigSchema.parse(req.body);
    const updated = await storage.updateBotConfig(config);
    res.json(updated);
  });

  // Gestion des serveurs
  app.get("/api/servers", async (req, res) => {
    const servers = await storage.getServers();
    res.json(servers);
  });

  // Commandes
  app.get("/api/commands", async (req, res) => {
    const commands = await storage.getCommands();
    res.json(commands);
  });

  app.post("/api/commands", async (req, res) => {
    const command = insertCommandSchema.parse(req.body);
    const created = await storage.createCommand(command);
    res.json(created);
  });

  app.patch("/api/commands/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const { enabled } = req.body;
    const updated = await storage.updateCommand(id, enabled);
    res.json(updated);
  });

  return httpServer;
}