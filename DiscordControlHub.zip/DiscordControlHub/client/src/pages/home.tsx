import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SiDiscord } from "react-icons/si";

export default function Home() {
  // L'URL d'authentification Discord sera configurée plus tard
  const handleLogin = () => {
    window.location.href = '/api/auth/discord';
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-[400px]">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            Tableau de Bord Bot Discord
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Button 
            className="w-full" 
            onClick={handleLogin}
            size="lg"
          >
            <SiDiscord className="mr-2 h-5 w-5" />
            Se connecter avec Discord
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}