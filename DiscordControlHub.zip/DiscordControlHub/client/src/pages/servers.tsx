import { useQuery } from "@tanstack/react-query";
import { ServerCard } from "@/components/server-card";
import type { Server } from "@shared/schema";

export default function Servers() {
  const { data: servers = [] } = useQuery<Server[]>({ 
    queryKey: ["/api/servers"]
  });

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Connected Servers</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {servers.map((server) => (
          <ServerCard key={server.id} server={server} />
        ))}
        
        {servers.length === 0 && (
          <div className="col-span-full text-center text-muted-foreground py-12">
            No servers connected yet
          </div>
        )}
      </div>
    </div>
  );
}
