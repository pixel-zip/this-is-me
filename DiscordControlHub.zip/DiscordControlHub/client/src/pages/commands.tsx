import { useQuery, useMutation } from "@tanstack/react-query";
import { Switch } from "@/components/ui/switch";
import { CommandTester } from "@/components/command-tester";
import type { Command } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Commands() {
  const { data: commands = [] } = useQuery<Command[]>({ 
    queryKey: ["/api/commands"]
  });

  const mutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => {
      await apiRequest("PATCH", `/api/commands/${id}`, { enabled });
    }
  });

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Commands</h1>
      
      <div className="space-y-4">
        {commands.map((command) => (
          <div key={command.id} className="flex items-start gap-4">
            <Switch
              checked={command.enabled}
              onCheckedChange={(enabled) => 
                mutation.mutate({ id: command.id, enabled })
              }
            />
            <div className="flex-1">
              <CommandTester command={command} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
