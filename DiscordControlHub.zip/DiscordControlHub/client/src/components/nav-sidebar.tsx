import { Link, useLocation } from "wouter";
import { Bot, Server, Command } from "lucide-react";

export function NavSidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border h-screen p-4">
      <div className="text-2xl font-bold mb-8 text-sidebar-foreground">
        Discord Bot
      </div>
      
      <nav className="space-y-2">
        <Link href="/">
          <a className={`flex items-center gap-2 p-2 rounded ${
            location === "/" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent/50"
          }`}>
            <Bot size={20} />
            <span>Dashboard</span>
          </a>
        </Link>
        
        <Link href="/servers">
          <a className={`flex items-center gap-2 p-2 rounded ${
            location === "/servers" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent/50"
          }`}>
            <Server size={20} />
            <span>Servers</span>
          </a>
        </Link>
        
        <Link href="/commands">
          <a className={`flex items-center gap-2 p-2 rounded ${
            location === "/commands" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent/50"
          }`}>
            <Command size={20} />
            <span>Commands</span>
          </a>
        </Link>
      </nav>
    </div>
  );
}
