import { Badge } from "@/components/ui/badge";

type Status = "online" | "offline" | "unconfigured";

interface StatusBadgeProps {
  status: Status;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const colors = {
    online: "bg-green-500",
    offline: "bg-red-500",
    unconfigured: "bg-yellow-500"
  };

  return (
    <Badge className={`${colors[status]} text-white`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
}
