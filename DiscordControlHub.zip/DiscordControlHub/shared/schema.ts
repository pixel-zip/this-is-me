import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Table de configuration pour le bot Discord
export const botConfig = pgTable("bot_config", {
  id: serial("id").primaryKey(),
  token: text("token").notNull(),
  prefix: text("prefix").notNull().default("!"),
  status: text("status").notNull().default("online"),
  activity: text("activity"),
});

// Table des serveurs Discord connectés
export const servers = pgTable("servers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  memberCount: integer("member_count").notNull(),
  icon: text("icon"),
  joined: timestamp("joined").notNull(),
});

// Table des commandes du bot
export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  enabled: boolean("enabled").notNull().default(true),
});

// Schémas pour la validation des données
export const insertBotConfigSchema = createInsertSchema(botConfig).omit({ id: true });
export const insertServerSchema = createInsertSchema(servers);
export const insertCommandSchema = createInsertSchema(commands).omit({ id: true });

// Types pour TypeScript
export type BotConfig = typeof botConfig.$inferSelect;
export type Server = typeof servers.$inferSelect;
export type Command = typeof commands.$inferSelect;
export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;
export type InsertServer = z.infer<typeof insertServerSchema>;
export type InsertCommand = z.infer<typeof insertCommandSchema>;
